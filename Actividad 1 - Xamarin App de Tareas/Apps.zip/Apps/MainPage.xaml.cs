﻿using System;
using System.IO;
using System.Collections.Generic;
using SQLite;
using TodoApp.Models;
using Xamarin.Forms;

namespace TodoApp
{
    public partial class MainPage : ContentPage
    {
        SQLiteConnection _db;

        public MainPage()
        {
            InitializeComponent();

            string path = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "tareas.db3");

            _db = new SQLiteConnection(path);
            _db.CreateTable<TaskItem>();
        }

        // Se llama CADA VEZ que la pantalla aparece — aquí estaba el bug
        protected override void OnAppearing()
        {
            base.OnAppearing();
            RefreshList();
        }

        void RefreshList()
        {
            List<TaskItem> tareas = _db.Table<TaskItem>().ToList();
            TaskList.ItemsSource = null; // fuerza el refresco visual
            TaskList.ItemsSource = tareas;
            CountLabel.Text = $"{tareas.Count} tarea{(tareas.Count != 1 ? "s" : "")}";
        }

        void OnAddClicked(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(NameEntry.Text))
            {
                DisplayAlert("Campo vacío", "El nombre de la tarea es obligatorio.", "OK");
                return;
            }

            _db.Insert(new TaskItem
            {
                Name = NameEntry.Text.Trim(),
                Description = DescEntry.Text?.Trim()
            });

            NameEntry.Text = "";
            DescEntry.Text = "";
            RefreshList();
        }

        async void OnTaskSelected(object sender, SelectedItemChangedEventArgs e)
        {
            if (e.SelectedItem is TaskItem task)
            {
                TaskList.SelectedItem = null;

                string accion = await DisplayActionSheet(
                    task.Name, "Cancelar", null,
                    task.IsCompleted ? "Marcar pendiente" : "Marcar completada",
                    "Eliminar");

                if (accion == "Eliminar")
                {
                    bool confirmar = await DisplayAlert(
                        "Eliminar", $"¿Eliminar \"{task.Name}\"?", "Sí", "No");
                    if (confirmar)
                    {
                        _db.Delete(task);
                        RefreshList();
                    }
                }
                else if (accion == "Marcar completada" || accion == "Marcar pendiente")
                {
                    task.IsCompleted = !task.IsCompleted;
                    _db.Update(task);
                    RefreshList();
                }
            }
        }
    }
}